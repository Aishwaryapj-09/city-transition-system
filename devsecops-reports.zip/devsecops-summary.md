# City Transition System DevSecOps Report

Generated: 2026-05-12T07:10:25.270Z
Single report folder: devsecops-reports
Legacy custom/k6 performance tests: removed. Performance evidence is shown through Grafana graphs backed by Prometheus metrics.

## Open First

- devsecops-reports/00-devsecops-demo-index.html
- devsecops-reports/devsecops-dashboard.html

## Concept Reports

- CHECK: Static Code Analysis Report -> 01-static-code-analysis-report.html
- MISSING: Unit Testing Report -> 02-unit-testing-report.html
- MISSING: Integration Testing Report -> 03-integration-testing-report.html
- MISSING: Code Coverage Testing Report -> 04-code-coverage-testing-report.html
- MISSING: Postman API Testing Report -> 05-postman-api-testing-report.html
- PASS: Prometheus Monitoring Report -> 06-prometheus-monitoring-report.html
- PASS: Grafana Performance Testing Report -> 07-grafana-performance-testing-report.html
- CHECK: Ansible IaC Report -> 08-ansible-iac-report.html
- MISSING: Deployment Flow Report -> 09-deployment-flow-report.html

## Key URLs

- Frontend: http://localhost:30007
- Backend health: http://localhost:30008/health
- Backend metrics: http://localhost:30008/metrics
- Prometheus targets: http://localhost:30090/targets
- Grafana: http://localhost:30300
